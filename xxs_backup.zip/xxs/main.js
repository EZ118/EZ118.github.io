function praise(id){
	alert("点赞功能已关闭!");
}